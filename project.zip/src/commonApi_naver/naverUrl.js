const NaverUrl = '/v1/search/movie.json?';

export default NaverUrl;
