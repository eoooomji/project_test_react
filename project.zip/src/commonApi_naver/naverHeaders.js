const NaverHeaders = {
  headers: {
    'Content-Type': 'application/json',
    'X-Naver-Client-Id': 'sB5VNjJkzBzmEmgRHlfb',
    'X-Naver-Client-Secret': 'S5XA7SWZ0Z',
  },
};

export default NaverHeaders;
