const Footer = () => {
  return (
    <>
      <div className='footer'>
        <p>FOOTER</p>
      </div>
    </>
  );
};

export default Footer;
