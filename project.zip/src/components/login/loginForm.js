const LoginForm = () => {
  return (
    <div>
      <p>로그인해주세요</p>
    </div>
  );
};

export default LoginForm;
