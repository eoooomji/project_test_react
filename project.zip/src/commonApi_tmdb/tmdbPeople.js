const TmdbPerson = 'https://api.themoviedb.org/3/person/';

export default TmdbPerson;
