const TMDB_KEY = '81c4bcbec59983aca3084740f6e3450e';

export default TMDB_KEY;
