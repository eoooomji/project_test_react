const TmdbsearchUrl = 'https://api.themoviedb.org/3/search/movie';

export default TmdbsearchUrl;
