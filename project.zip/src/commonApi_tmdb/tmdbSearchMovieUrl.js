const TmdbSearchMovieUrl = 'https://api.themoviedb.org/3/search/movie';

export default TmdbSearchMovieUrl;
