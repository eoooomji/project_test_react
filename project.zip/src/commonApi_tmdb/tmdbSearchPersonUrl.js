const TmdbSearchPeopleUrl = 'https://api.themoviedb.org/3/search/person';

export default TmdbSearchPeopleUrl;
