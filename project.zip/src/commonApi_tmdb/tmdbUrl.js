const TmdbUrl = 'https://api.themoviedb.org/3/movie';

export default TmdbUrl;
