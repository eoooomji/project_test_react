const TmdbdiscoverUrl = 'https://api.themoviedb.org/3/discover/movie';

export default TmdbdiscoverUrl;
