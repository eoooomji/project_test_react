const searchUrl = 'https://api.themoviedb.org/3/search/movie';

export default searchUrl;
