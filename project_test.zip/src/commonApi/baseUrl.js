const baseUrl = 'https://api.themoviedb.org/3/movie';

export default baseUrl;
