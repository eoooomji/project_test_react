const NaverHeaders = {
  headers: {
    'Content-Type': 'application/json',
    'X-Naver-Client-Id': '1AZu2ARHxSTGMdaorTiv',
    'X-Naver-Client-Secret': 'lGSFiT1ELY',
  },
};

export default NaverHeaders;
